import numpy as np
import csv
import sys
from time import time
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
import operator
from functools import reduce

data = []
with open('movie_metadata.csv', 'rb') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',')
    for row in spamreader:
        data.append(row)
l1 = len(data)
typ = data[0]
header = data[1]
data = data[2:l1]
l2 = len(data)
print l2

attributes = [[]]*23
column = np.array(data)
column = column.transpose()
column = column.tolist()

categoricalData = []
categoricalCols = []

attbs = map(np.unique,column)

for i in range(23):
    if typ[i] == 'I':
        column[i] = [int(j) for j in column[i] if j != '']        
    elif typ[i] == 'F':
        column[i] = [float(j) for j in column[i] if j != '']
    elif typ[i] == 'C':
        categoricalCols.append(i)
        categoricalData.append(attbs[i].tolist())                

#print categoricalData

for i in range(len(attributes[0])):
    attributes[0][i] =  i
for i in range(len(attributes[5])):
    attributes[5][i] =  i
for i in range(len(attributes[8])):
    attributes[8][i] =  i
for i in range(len(attributes[9])):
    attributes[9][i] =  i
for i in range(len(attributes[10])):
    attributes[10][i] =  i
for i in range(len(attributes[13])):
    attributes[13][i] =  i
for i in range(len(attributes[15])):
    attributes[15][i] =  i
for i in range(len(attributes[16])):
    attributes[16][i] =  i

    
#print categoricalData
#print categoricalCols

for i in range(l2):
    data[i][0] = categoricalData[0].index(data[i][0])
    data[i][5] = categoricalData[1].index(data[i][5])
    data[i][8] = categoricalData[2].index(data[i][8])
    data[i][9] = categoricalData[3].index(data[i][9])
    data[i][10] = categoricalData[4].index(data[i][10])
    data[i][13] = categoricalData[5].index(data[i][13])
    data[i][15] = categoricalData[6].index(data[i][15])
    data[i][16] = categoricalData[7].index(data[i][16])
    

for i in range(l2):
    if float(data[i][22]) >= 5.0:
        data[i][22] = 1
    else:
        data[i][22] = 0

fdata = data
for i in range(len(fdata)):
    for j in range(len(fdata[i])):
        if(fdata[i][j] != ""):
            fdata[i][j] = float(fdata[i][j])
        else:
            fdata[i][j] = 0.0
    
featureData = []
labelsData = []

for i in range(l2):
    featureData.append(fdata[i][:22])
    labelsData.append(fdata[i][22:])

features_train = []
features_test = []
labels_train = []
labels_test = []

for i in range(700):
    features_train.append(featureData[i])
    labels_train.append(labelsData[i])
    
for i in range(700,1000):
    features_test.append(featureData[i])
    labels_test.append(labelsData[i])

labels_train =reduce(lambda x,y: x+y,labels_train)
labels_test = (reduce(operator.concat,labels_test))

clf = GaussianNB()  #Naive Bayesian
t0 = time()
clf.fit(features_train, labels_train)

t1 = time()
pred = clf.predict(features_test)
acc = (accuracy_score(labels_test, pred))
print acc*100,"%"      

